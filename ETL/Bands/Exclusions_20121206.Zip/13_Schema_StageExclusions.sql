USE MixStaging
go

CREATE SCHEMA StageExclusion